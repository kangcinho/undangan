{{-- <nav class="navbar navbar-primary bg-dark" > --}}
  {{-- <ul class="nav  bg-dark nav-pills nav-fill ">
    <li class="nav-item">
      <a class="nav-link text-white" href="{{ url('admin/list') }}">List</a>
    </li>
    <li class="nav-item">
      <a class="nav-link text-white" href="{{ url('admin/input') }}">Input</a>
    </li>
    @auth
    <li class="nav-item">
      <form action="/admin/logout" method="post">
        @csrf
        <button type="submit" class="nav-link text-white">Logout</button>
      </form>
    </li>
    @endauth
  </ul> --}}
{{-- </nav> --}}

<nav class="navbar navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="#">Undangan</a>
    
    <ul class="nav  ">
      <li class="nav-item">
        <a class="nav-link text-white" href="{{ url('admin/list') }}">List</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-white" href="{{ url('admin/input') }}">Input</a>
      </li>
      @auth
        <li class="nav-item">
          <form action="/admin/logout" method="post">
            @csrf
            <button type="submit" class="btn btn-text nav-link text-white">Logout</button>
          </form>
        </li>
      @endauth
    </ul>
  </div>
</nav>

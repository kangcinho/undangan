<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">    
    <title>DAFTAR DATA PERNIKAHAN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
</head>
<body>
  @include('share.nav')

    <div class="container">
      <h1>Daftar Client</h1>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">URL Undangan</th>
            <th scope="col">Nama Suami</th>
            <th scope="col">Nama Istri</th>
            <th scope="col">Tanggal Nikah</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          @if(count($invites) > 0)
            @foreach($invites as $invite)
              <tr>
                <td scope="row"> {{ $invite->url_invite }}</td>
                <td scope="row"> {{ $invite->nama_suami }}</td>
                <td scope="row"> {{ $invite->nama_istri }}</td>
                <td scope="row"> {{ date('d-m-Y', strtotime($invite->tanggal_nikah)) }}</td>
                <td>
                  <a class="btn btn-primary" href="{{ url('/'. $invite->url_invite) }}">Lihat Undangan</a>
                  <a class="btn btn-warning" href="{{ url('admin/update/'. $invite->id) }}">Edit</a>
                  <a class="btn btn-danger" href="javascript:void(0)" onClick="confirmDelete('{{  $invite->nama_suami }}' , '{{ $invite->nama_istri }}' , '{{ url("admin/delete/". $invite->url_invite) }}' )">Hapus</a>
                </td>
              </tr>
            @endforeach
          @endif
               
        </tbody>
      </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    <script>
      function confirmDelete(namaSuami, namaIstri, url) {
        if(confirm(`Yakin Hapus Undangan ${namaSuami} - ${namaIstri}`)){
          window.location.href = url
        }
      }
    </script>
</body>
</html>

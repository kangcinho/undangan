<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>INPUT DATA PERNIKAHAN</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
</head>
<body >
  <?php echo $__env->make('share.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container">
      <form action=<?php echo e(isset($data)? "/admin/update/".$data->id : "/admin/input"); ?> method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value=<?php echo e(isset($data)?$data->id: ""); ?> />
        <div class="row">
          <h6 class="mt-3">Url dan Tema</h6>
          <hr>
          <div class="col-4">
            <label for="url_invite" class="form-label">URL</label>
            <input type="text"  class="form-control" id="url_invite" name="url_invite" value="<?php echo e(isset($data)?$data->url_invite: ''); ?>" <?php echo e(isset($data)? "readonly" : ''); ?> required>
          </div>

          <div class="col-4">
            <label for="tema" class="form-label">Tema</label>
            <select class="form-select" id="tema_id" name="tema_id" value="<?php echo e(isset($data)?$data->tema_id: ''); ?>" required>
              <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tema->id); ?>" <?php echo e(isset($data)? $data->tema_id == $tema->id? 'selected': '' : ''); ?>><?php echo e($tema->nama); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <div class="col-4">
            <label for="foto_header" class="form-label">Foto Header</label>
            <input type="file" class="form-control" id="foto_header" name="foto_header">
          </div>
        </div>

        <div class="row">
          <h6 class="mt-3">Identitas Pengantin</h6>
          <hr>
          <div class="col-4">
            <label for="nama_suami" class="form-label">Nama Suami</label>
            <input type="text" class="form-control" id="nama_suami" name="nama_suami" value="<?php echo e(isset($data)?$data->nama_suami: ''); ?>" required>
          </div>
          
          <div class="col-4">
            <label for="foto_suami" class="form-label">Foto Suami</label>
            <input type="file" class="form-control" id="foto_suami" name="foto_suami">
          </div>

          <div class="col-4">
            <label for="nama_suami_initial" class="form-label">Nama Suami Inisial</label>
            <input type="text" class="form-control" id="nama_suami_initial" name="nama_suami_initial" value="<?php echo e(isset($data)?$data->nama_suami_initial: ''); ?>" required>
          </div>

          <div class="col-4">
            <label for="nama_istri" class="form-label">Nama Istri</label>
            <input type="text" class="form-control" id="nama_istri" name="nama_istri" value="<?php echo e(isset($data)?$data->nama_istri: ''); ?>" required>
          </div>
          
          <div class="col-4">
            <label for="foto_istri" class="form-label">Foto Istri</label>
            <input type="file" class="form-control" id="foto_istri" name="foto_istri">
          </div>

          <div class="col-4">
            <label for="nama_istri_initial" class="form-label">Nama Istri Inisial</label>
            <input type="text" class="form-control" id="nama_istri_initial" name="nama_istri_initial" value="<?php echo e(isset($data)?$data->nama_istri_initial: ''); ?>" required>
          </div>

          <div class="col-6">
            <label for="tanggal_nikah" class="form-label">Tanggal Menikah</label>
            <input type="date" class="form-control" id="tanggal_nikah" name="tanggal_nikah" value="<?php echo e(isset($data)?$data->tanggal_nikah: ''); ?>" required>
          </div>
          
          <div class="col-6">
            <label for="kata_mutiara" class="form-label">Kata-Kata Pembuka</label>
            <input type="text" class="form-control" id="kata_mutiara" name="kata_mutiara" value="<?php echo e(isset($data)?$data->kata_mutiara: 'Dua jiwa namun satu pikiran, dua hati namun satu perasaan'); ?>" required>
          </div>
        </div>

        <div class="row">
          <h6 class="mt-3">Identitas Orang Tua</h6>
          <hr>
          <div class="col-6">
            <label for="nama_suami_ortu_bapak" class="form-label">Suami: Nama Bapak</label>
            <input type="text" class="form-control" id="nama_suami_ortu_bapak" name="nama_suami_ortu_bapak" value="<?php echo e(isset($data)?$data->nama_suami_ortu_bapak: ''); ?>" required>
          </div>

          <div class="col-6">
            <label for="nama_suami_ortu_ibu" class="form-label">Suami: Nama Ibu</label>
            <input type="text" class="form-control" id="nama_suami_ortu_ibu" name="nama_suami_ortu_ibu" value="<?php echo e(isset($data)?$data->nama_suami_ortu_ibu: ''); ?>" required>
          </div>

          <div class="col-6">
            <label for="nama_istri_ortu_bapak" class="form-label">Istri: Nama Bapak</label>
            <input type="text" class="form-control" id="nama_istri_ortu_bapak" name="nama_istri_ortu_bapak" value="<?php echo e(isset($data)?$data->nama_istri_ortu_bapak: ''); ?>" required>
          </div>

          <div class="col-6">
            <label for="nama_istri_ortu_ibu" class="form-label">Istri: Nama Ibu</label>
            <input type="text" class="form-control" id="nama_istri_ortu_ibu" name="nama_istri_ortu_ibu" value="<?php echo e(isset($data)?$data->nama_istri_ortu_ibu: ''); ?>" required>
          </div>
        </div>
        
        <div class="row">  
          <h6 class="mt-3">Pepatah</h6>
          <div class="col-4">
            <label for="pepatah_foto" class="form-label">Background Section Pepatah</label>
            <input type="file" class="form-control" id="pepatah_foto" name="pepatah_foto" />
          </div>
          <div class="col-4">
            <label for="pepatah_kata" class="form-label">Kata-kata Pepatah</label>
            <input type="text" class="form-control" id="pepatah_kata" name="pepatah_kata" value="<?php echo e(isset($data)?$data->pepatah_kata: 'Wahai pasangan suami-isteri, semoga kalian tetap bersatu dan tidak pernah terpisahkan. Semoga kalian mencapai hidup penuh kebahagiaan, tinggal di rumah yang penuh kegembiraan bersama seluruh keturunanmu.'); ?>" required>
          </div>
          <div class="col-4">
            <label for="pepatah_author" class="form-label">Pepatah Author</label>
            <input type="text" class="form-control" id="pepatah_author" name="pepatah_author" value="<?php echo e(isset($data)?$data->pepatah_author: 'Rgveda : X.85.42'); ?>" required>
          </div>
        </div>

        <div class="row">  
          <h6 class="mt-3">Galery</h6>
          <hr>
          <div class="col-4">
            <label for="galeri_keterangan" class="form-label">Kata-kata Pembuka Galeri</label>
            <input type="text" class="form-control" id="galeri_keterangan" name="galeri_keterangan" value="<?php echo e(isset($data)?$data->galeri_keterangan: ''); ?>" >
          </div>

          <div class="col-4">
            <label for="galeri_top1" class="form-label">Galeri Top 1</label>
            <input type="file" class="form-control" id="galeri_top1" name="galeri_top1">
          </div>

          <div class="col-4">
            <label for="galeri_top2" class="form-label">Galeri Top 2</label>
            <input type="file" class="form-control" id="galeri_top2" name="galeri_top2">
          </div>

          <div class="col-4">
            <label for="galeri_top3" class="form-label">Galeri Top 3</label>
            <input type="file" class="form-control" id="galeri_top3" name="galeri_top3">
          </div>

          <div class="col-4">
            <label for="galeri_middle" class="form-label">Galeri Middle</label>
            <input type="file" class="form-control" id="galeri_middle" name="galeri_middle">
          </div>

          <div class="col-4">
            <label for="galeri_bottom1" class="form-label">Galleri Bottom 1</label>
            <input type="file" class="form-control" id="galeri_bottom1" name="galeri_bottom1">
          </div>

          <div class="col-4">
            <label for="galeri_bottom2" class="form-label">Galleri Bottom 2</label>
            <input type="file" class="form-control" id="galeri_bottom2" name="galeri_bottom2">
          </div>

          <div class="col-4">
            <label for="galeri_bottom3" class="form-label">Galleri Bottom 3</label>
            <input type="file" class="form-control" id="galeri_bottom3" name="galeri_bottom3">
          </div>

          <div class="col-4">
            <label for="galeri_bottom4" class="form-label">Galleri Bottom 4</label>
            <input type="file" class="form-control" id="galeri_bottom4" name="galeri_bottom4">
          </div>

          <div class="col-4">
            <label for="galeri_bottom5" class="form-label">Galleri Bottom 5</label>
            <input type="file" class="form-control" id="galeri_bottom5" name="galeri_bottom5">
          </div>

          <div class="col-4">
            <label for="galeri_bottom6" class="form-label">Galleri Bottom 6</label>
            <input type="file" class="form-control" id="galeri_bottom6" name="galeri_bottom6">
          </div>
        </div>

        <div class="row">
          <h6 class="mt-3">Media Pendukung</h6>
          <hr>
          <div class="col-6">
            <label for="video" class="form-label">Video</label>
            <input type="file" class="form-control" id="video" name="video">
          </div>

          <div class="col-6">
            <label for="music" class="form-label">Music</label>
            <input type="file" class="form-control" id="music" name="music">
          </div>
        </div>


        <div class="row">
          <h6 class="mt-3">Jadwal Pernikahan</h6>
          <hr>
          <div class="col-4">
            <label for="jadwal_nikah_pembuka" class="form-label">Kata Sambutan Pembuka</label>
            <input type="text" class="form-control" id="jadwal_nikah_pembuka" name="jadwal_nikah_pembuka" value="<?php echo e(isset($data)?$data->jadwal_nikah_pembuka: 'Om Swastyastu'); ?>" required>
          </div>

          <div class="col-4">
            <label for="jadwal_nikah_isi" class="form-label">Kata-Kata Pembuka</label>
            <input type="text" class="form-control" id="jadwal_nikah_isi" name="jadwal_nikah_isi" value="<?php echo e(isset($data)?$data->jadwal_nikah_isi: 'Atas Asung Kertha Wara Nugraha Ida Sang Hyang Widhi Wasa/Tuhan Yang Maha Esa, kami bermaksud mengundang Bapak/Ibu/Saudara/i pada Upacara Manusa Yadnya Pawiwahan (Pernikahan) Kami: '); ?>" required>
          </div>

          <div class="col-4">
            <label for="jadwal_nikah_tanggal" class="form-label">Tanggal Nikah Terbilang</label>
            <input type="text" class="form-control" id="jadwal_nikah_tanggal" name="jadwal_nikah_tanggal" value="<?php echo e(isset($data)?$data->jadwal_nikah_tanggal: ''); ?>" required placeholder="Senin, 31 Januari 1990">
          </div>

          <div class="col-4">
            <label for="jadwal_nikah_waktu" class="form-label">Pukul Nikah Terbilang</label>
            <input type="text" class="form-control" id="jadwal_nikah_waktu" name="jadwal_nikah_waktu" value="<?php echo e(isset($data)?$data->jadwal_nikah_waktu: ''); ?>" required placeholder="09.00 - Selesai">
          </div>

          <div class="col-4">
            <label for="jadwal_nikah_lokasi" class="form-label">Lokasi Nikah</label>
            <input type="text" class="form-control" id="jadwal_nikah_lokasi" name="jadwal_nikah_lokasi" value="<?php echo e(isset($data)?$data->jadwal_nikah_lokasi: ''); ?>" required>
          </div>

          <div class="col-4">
            <label for="jadwal_nikah_lokasi_link" class="form-label">Link Google Map Lokasi Nikah</label>
            <input type="text" class="form-control" id="jadwal_nikah_lokasi_link" name="jadwal_nikah_lokasi_link" value="<?php echo e(isset($data)?$data->jadwal_nikah_lokasi_link: ''); ?>" required>
          </div>

          

          <div class="col-4">
            <label for="jadwal_isi_bottom" class="form-label">Kata-Kata Penutup</label>
            <input type="text" class="form-control" id="jadwal_isi_bottom" name="jadwal_isi_bottom" value="<?php echo e(isset($data)?$data->jadwal_isi_bottom: 'Merupakan suatu Kehormatan dan Kebahagiaan Bagi Kami, Apabila Bapak/Ibu/Saudara/i Berkenan Hadir Untuk memberikan Doa Restu Kepada kedua mempelai.'); ?>" required>
          </div>

          <div class="col-4">
            <label for="jadwal_penutup" class="form-label">Kata Sambutan Penutup</label>
            <input type="text" class="form-control" id="jadwal_penutup" name="jadwal_penutup" value="<?php echo e(isset($data)?$data->jadwal_penutup: 'Om Santhi, Santhi, Santhi, Om'); ?>" required>
          </div>
        </div>
        
        
        <div class="row mt-3">
          <div class="d-grid gap-2 d-md-block">
            <button class="btn btn-primary" type="submit">Simpan</button>
          </div>
        </div>
      </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH D:\__DEV\Ho\undangan\resources\views/input/input.blade.php ENDPATH**/ ?>
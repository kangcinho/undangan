<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    
    <title>INPUT DATA PERNIKAHAN</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
</head>
<body >
    <div class="container">
      <form action=<?php echo e(isset($data)? "/admin/update/".$data->id : "/admin/input"); ?> method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input type="hidden" name="id" value=<?php echo e(isset($data)?$data->id: ""); ?> />
        <div class="row">
          <h6 class="mt-3">Url dan Tema</h6>
          <hr>
          <div class="col-4">
            <label for="url_invite" class="form-label">URL</label>
            <input type="text" class="form-control" id="url_invite" name="url_invite" value="<?php echo e(isset($data)?$data->url_invite: ''); ?>" <?php echo e(isset($data)? "readonly" : ''); ?>>
          </div>

          <div class="col-4">
            <label for="tema" class="form-label">Tema</label>
            <select class="form-select" id="tema_id" name="tema_id" value="<?php echo e(isset($data)?$data->tema_id: ''); ?>">
              <?php $__currentLoopData = $themes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tema): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($tema->id); ?>" <?php echo e($data->tema_id == $tema->id? 'selected': ''); ?>><?php echo e($tema->nama); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>

          <div class="col-4">
            <label for="foto_header" class="form-label">foto_header</label>
            <input type="file" class="form-control" id="foto_header" name="foto_header">
          </div>
        </div>

        <div class="row">
          <h6 class="mt-3">Identitas Pengantin</h6>
          <hr>
          <div class="col-4">
            <label for="nama_suami" class="form-label">nama_suami</label>
            <input type="text" class="form-control" id="nama_suami" name="nama_suami" value="<?php echo e(isset($data)?$data->nama_suami: ''); ?>">
          </div>
          
          <div class="col-4">
            <label for="foto_suami" class="form-label">foto_suami</label>
            <input type="file" class="form-control" id="foto_suami" name="foto_suami">
          </div>

          <div class="col-4">
            <label for="nama_suami_initial" class="form-label">nama_suami_initial</label>
            <input type="text" class="form-control" id="nama_suami_initial" name="nama_suami_initial" value="<?php echo e(isset($data)?$data->nama_suami_initial: ''); ?>">
          </div>

          <div class="col-4">
            <label for="nama_istri" class="form-label">nama_istri</label>
            <input type="text" class="form-control" id="nama_istri" name="nama_istri" value="<?php echo e(isset($data)?$data->nama_istri: ''); ?>">
          </div>
          
          <div class="col-4">
            <label for="foto_istri" class="form-label">foto_istri</label>
            <input type="file" class="form-control" id="foto_istri" name="foto_istri">
          </div>

          <div class="col-4">
            <label for="nama_istri_initial" class="form-label">nama_istri_initial</label>
            <input type="text" class="form-control" id="nama_istri_initial" name="nama_istri_initial" value="<?php echo e(isset($data)?$data->nama_istri_initial: ''); ?>">
          </div>

          <div class="col-6">
            <label for="tanggal_nikah" class="form-label">tanggal_nikah</label>
            <input type="date" class="form-control" id="tanggal_nikah" name="tanggal_nikah" value="<?php echo e(isset($data)?$data->tanggal_nikah: ''); ?>">
          </div>
          
          <div class="col-6">
            <label for="kata_mutiara" class="form-label">kata_mutiara</label>
            <input type="text" class="form-control" id="kata_mutiara" name="kata_mutiara" value="<?php echo e(isset($data)?$data->kata_mutiara: ''); ?>">
          </div>
        </div>

        <div class="row">
          <h6 class="mt-3">Identitas Orang Tua</h6>
          <hr>
          <div class="col-6">
            <label for="nama_suami_ortu_bapak" class="form-label">nama_suami_ortu_bapak</label>
            <input type="text" class="form-control" id="nama_suami_ortu_bapak" name="nama_suami_ortu_bapak" value="<?php echo e(isset($data)?$data->nama_suami_ortu_bapak: ''); ?>">
          </div>

          <div class="col-6">
            <label for="nama_suami_ortu_ibu" class="form-label">nama_suami_ortu_ibu</label>
            <input type="text" class="form-control" id="nama_suami_ortu_ibu" name="nama_suami_ortu_ibu" value="<?php echo e(isset($data)?$data->nama_suami_ortu_ibu: ''); ?>">
          </div>

          <div class="col-6">
            <label for="nama_istri_ortu_bapak" class="form-label">nama_istri_ortu_bapak</label>
            <input type="text" class="form-control" id="nama_istri_ortu_bapak" name="nama_istri_ortu_bapak" value="<?php echo e(isset($data)?$data->nama_istri_ortu_bapak: ''); ?>">
          </div>

          <div class="col-6">
            <label for="nama_istri_ortu_ibu" class="form-label">nama_istri_ortu_ibu</label>
            <input type="text" class="form-control" id="nama_istri_ortu_ibu" name="nama_istri_ortu_ibu" value="<?php echo e(isset($data)?$data->nama_istri_ortu_ibu: ''); ?>">
          </div>
        </div>
        <?php if(isset($data)): ?>
          <?php for($i=0; $i<count($data->story); $i++): ?>
            <div class="row mt-3">
              <input type="hidden" name="kisah_cinta_id[]" value="<?php echo e($data->story[$i]->id); ?>">
              <h6>Kisah Cinta <?php echo e($i+1); ?></h6>
              <hr/>
              <div class="col-6">
                <label for="kisah_cinta_tahun" class="form-label">kisah_cinta_tahun</label>
                <input type="text" class="form-control" id="kisah_cinta_tahun" name="kisah_cinta_tahun[]" value="<?php echo e($data->story[$i]->kisah_cinta_tahun); ?>">
              </div>
              <div class="col-6">
                <label for="kisah_cinta_judul" class="form-label">kisah_cinta_judul</label>
                <input type="text" class="form-control" id="kisah_cinta_judul" name="kisah_cinta_judul[]" value="<?php echo e($data->story[$i]->kisah_cinta_judul); ?>">
              </div>
              <div class="col-6">
                <label for="kisah_cinta_isi" class="form-label">kisah_cinta_isi</label>
                <input type="text" class="form-control" id="kisah_cinta_isi" name="kisah_cinta_isi[]" value="<?php echo e($data->story[$i]->kisah_cinta_isi); ?>">
              </div>
              <div class="col-6">
                <label for="kisah_cinta_foto" class="form-label">kisah_cinta_foto</label>
                <input type="file" class="form-control" id="kisah_cinta_foto" name="kisah_cinta_foto[]" >
              </div>
            </div>
          <?php endfor; ?>          
        <?php else: ?>
        <div class="row mt-3">          
          <h6>Kisah Cinta 1</h6>
          <hr/>
          <div class="col-6">
            <label for="kisah_cinta_tahun" class="form-label">kisah_cinta_tahun</label>
            <input type="text" class="form-control" id="kisah_cinta_tahun" name="kisah_cinta_tahun[]">
          </div>
          <div class="col-6">
            <label for="kisah_cinta_judul" class="form-label">kisah_cinta_judul</label>
            <input type="text" class="form-control" id="kisah_cinta_judul" name="kisah_cinta_judul[]" >
          </div>
          <div class="col-6">
            <label for="kisah_cinta_isi" class="form-label">kisah_cinta_isi</label>
            <input type="text" class="form-control" id="kisah_cinta_isi" name="kisah_cinta_isi[]" >
          </div>
          <div class="col-6">
            <label for="kisah_cinta_foto" class="form-label">kisah_cinta_foto</label>
            <input type="file" class="form-control" id="kisah_cinta_foto" name="kisah_cinta_foto[]" >
          </div>
          <h6>Kisah Cinta 2</h6>
          <hr/>
          <div class="col-6">
            <label for="kisah_cinta_tahun" class="form-label">kisah_cinta_tahun</label>
            <input type="text" class="form-control" id="kisah_cinta_tahun" name="kisah_cinta_tahun[]">
          </div>
          <div class="col-6">
            <label for="kisah_cinta_judul" class="form-label">kisah_cinta_judul</label>
            <input type="text" class="form-control" id="kisah_cinta_judul" name="kisah_cinta_judul[]" >
          </div>
          <div class="col-6">
            <label for="kisah_cinta_isi" class="form-label">kisah_cinta_isi</label>
            <input type="text" class="form-control" id="kisah_cinta_isi" name="kisah_cinta_isi[]" >
          </div>
          <div class="col-6">
            <label for="kisah_cinta_foto" class="form-label">kisah_cinta_foto</label>
            <input type="file" class="form-control" id="kisah_cinta_foto" name="kisah_cinta_foto[]" >
          </div>
          <h6>Kisah Cinta 3</h6>
          <hr/>
          <div class="col-6">
            <label for="kisah_cinta_tahun" class="form-label">kisah_cinta_tahun</label>
            <input type="text" class="form-control" id="kisah_cinta_tahun" name="kisah_cinta_tahun[]">
          </div>
          <div class="col-6">
            <label for="kisah_cinta_judul" class="form-label">kisah_cinta_judul</label>
            <input type="text" class="form-control" id="kisah_cinta_judul" name="kisah_cinta_judul[]" >
          </div>
          <div class="col-6">
            <label for="kisah_cinta_isi" class="form-label">kisah_cinta_isi</label>
            <input type="text" class="form-control" id="kisah_cinta_isi" name="kisah_cinta_isi[]" >
          </div>
          <div class="col-6">
            <label for="kisah_cinta_foto" class="form-label">kisah_cinta_foto</label>
            <input type="file" class="form-control" id="kisah_cinta_foto" name="kisah_cinta_foto[]" >
          </div>
        </div>
        <?php endif; ?>
        

        <div class="row">  
          <h6 class="mt-3">Galery</h6>
          <hr>
          <div class="col-4">
            <label for="galeri_keterangan" class="form-label">galeri_keterangan</label>
            <input type="text" class="form-control" id="galeri_keterangan" name="galeri_keterangan" value="<?php echo e(isset($data)?$data->galeri_keterangan: ''); ?>">
          </div>

          <div class="col-4">
            <label for="galeri_top1" class="form-label">galeri_top1</label>
            <input type="file" class="form-control" id="galeri_top1" name="galeri_top1">
          </div>

          <div class="col-4">
            <label for="galeri_top2" class="form-label">galeri_top2</label>
            <input type="file" class="form-control" id="galeri_top2" name="galeri_top2">
          </div>

          <div class="col-4">
            <label for="galeri_top3" class="form-label">galeri_top3</label>
            <input type="file" class="form-control" id="galeri_top3" name="galeri_top3">
          </div>

          <div class="col-4">
            <label for="galeri_middle" class="form-label">galeri_middle</label>
            <input type="file" class="form-control" id="galeri_middle" name="galeri_middle">
          </div>

          <div class="col-4">
            <label for="galeri_bottom1" class="form-label">galeri_bottom1</label>
            <input type="file" class="form-control" id="galeri_bottom1" name="galeri_bottom1">
          </div>

          <div class="col-4">
            <label for="galeri_bottom2" class="form-label">galeri_bottom2</label>
            <input type="file" class="form-control" id="galeri_bottom2" name="galeri_bottom2">
          </div>

          <div class="col-4">
            <label for="galeri_bottom3" class="form-label">galeri_bottom3</label>
            <input type="file" class="form-control" id="galeri_bottom3" name="galeri_bottom3">
          </div>

          <div class="col-4">
            <label for="galeri_bottom4" class="form-label">galeri_bottom4</label>
            <input type="file" class="form-control" id="galeri_bottom4" name="galeri_bottom4">
          </div>

          <div class="col-4">
            <label for="galeri_bottom5" class="form-label">galeri_bottom5</label>
            <input type="file" class="form-control" id="galeri_bottom5" name="galeri_bottom5">
          </div>

          <div class="col-4">
            <label for="galeri_bottom6" class="form-label">galeri_bottom6</label>
            <input type="file" class="form-control" id="galeri_bottom6" name="galeri_bottom6">
          </div>
        </div>

        <div class="row">
          <h6 class="mt-3">Media Pendukung</h6>
          <hr>
          <div class="col-6">
            <label for="video" class="form-label">video</label>
            <input type="file" class="form-control" id="video" name="video">
          </div>

          <div class="col-6">
            <label for="music" class="form-label">music</label>
            <input type="file" class="form-control" id="music" name="music">
          </div>
        </div>


        <div class="row">
          <h6 class="mt-3">Jadwal Pernikahan</h6>
          <hr>
          <div class="col-4">
            <label for="jadwal_nikah_pembuka" class="form-label">jadwal_nikah_pembuka</label>
            <input type="text" class="form-control" id="jadwal_nikah_pembuka" name="jadwal_nikah_pembuka" value="<?php echo e(isset($data)?$data->jadwal_nikah_pembuka: ''); ?>">
          </div>

          <div class="col-4">
            <label for="jadwal_nikah_isi" class="form-label">jadwal_nikah_isi</label>
            <input type="text" class="form-control" id="jadwal_nikah_isi" name="jadwal_nikah_isi" value="<?php echo e(isset($data)?$data->jadwal_nikah_isi: ''); ?>">
          </div>

          <div class="col-4">
            <label for="jadwal_nikah_tanggal" class="form-label">jadwal_nikah_tanggal</label>
            <input type="text" class="form-control" id="jadwal_nikah_tanggal" name="jadwal_nikah_tanggal" value="<?php echo e(isset($data)?$data->jadwal_nikah_tanggal: ''); ?>">
          </div>

          <div class="col-4">
            <label for="jadwal_nikah_waktu" class="form-label">jadwal_nikah_waktu</label>
            <input type="text" class="form-control" id="jadwal_nikah_waktu" name="jadwal_nikah_waktu" value="<?php echo e(isset($data)?$data->jadwal_nikah_waktu: ''); ?>">
          </div>

          <div class="col-4">
            <label for="jadwal_nikah_lokasi" class="form-label">jadwal_nikah_lokasi</label>
            <input type="text" class="form-control" id="jadwal_nikah_lokasi" name="jadwal_nikah_lokasi" value="<?php echo e(isset($data)?$data->jadwal_nikah_lokasi: ''); ?>">
          </div>

          <div class="col-4">
            <label for="jadwal_nikah_lokasi_link" class="form-label">jadwal_nikah_lokasi_link</label>
            <input type="text" class="form-control" id="jadwal_nikah_lokasi_link" name="jadwal_nikah_lokasi_link" value="<?php echo e(isset($data)?$data->jadwal_nikah_lokasi_link: ''); ?>">
          </div>

          <div class="col-4">
            <label for="jadwal_resepsi_tanggal" class="form-label">jadwal_resepsi_tanggal</label>
            <input type="text" class="form-control" id="jadwal_resepsi_tanggal" name="jadwal_resepsi_tanggal" value="<?php echo e(isset($data)?$data->jadwal_resepsi_tanggal: ''); ?>">
          </div>

          <div class="col-4">
            <label for="jadwal_resepsi_waktu" class="form-label">jadwal_resepsi_waktu</label>
            <input type="text" class="form-control" id="jadwal_resepsi_waktu" name="jadwal_resepsi_waktu" value="<?php echo e(isset($data)?$data->jadwal_resepsi_waktu: ''); ?>">
          </div>

          <div class="col-4">
            <label for="jadwal_resepsi_lokasi" class="form-label">jadwal_resepsi_lokasi</label>
            <input type="text" class="form-control" id="jadwal_resepsi_lokasi" name="jadwal_resepsi_lokasi" value="<?php echo e(isset($data)?$data->jadwal_resepsi_lokasi: ''); ?>">
          </div>

          <div class="col-4">
            <label for="jadwal_resepsi_lokasi_link" class="form-label">jadwal_resepsi_lokasi_link</label>
            <input type="text" class="form-control" id="jadwal_resepsi_lokasi_link" name="jadwal_resepsi_lokasi_link" value="<?php echo e(isset($data)?$data->jadwal_resepsi_lokasi_link: ''); ?>">
          </div>

          <div class="col-4">
            <label for="jadwal_isi_bottom" class="form-label">jadwal_isi_bottom</label>
            <input type="text" class="form-control" id="jadwal_isi_bottom" name="jadwal_isi_bottom" value="<?php echo e(isset($data)?$data->jadwal_isi_bottom: ''); ?>">
          </div>

          <div class="col-4">
            <label for="jadwal_penutup" class="form-label">jadwal_penutup</label>
            <input type="text" class="form-control" id="jadwal_penutup" name="jadwal_penutup" value="<?php echo e(isset($data)?$data->jadwal_penutup: ''); ?>">
          </div>
        </div>
        
        <div class="row">
          <h6 class="mt-3">Sosial Media</h6>
          <hr>
          <div class="col-6">
            <label for="link_instagram" class="form-label">link_instagram</label>
            <input type="text" class="form-control" id="link_instagram" name="link_instagram" value="<?php echo e(isset($data)?$data->link_instagram: ''); ?>">
          </div>

          <div class="col-6">
            <label for="link_facebook" class="form-label">link_facebook</label>
            <input type="text" class="form-control" id="link_facebook" name="link_facebook" value="<?php echo e(isset($data)?$data->link_facebook: ''); ?>">
          </div>
        </div>
        <div class="row mt-3">
          <div class="d-grid gap-2 d-md-block">
            <button class="btn btn-primary" type="submit">Simpan</button>
          </div>
        </div>
      </form>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
</body>
</html>
<?php /**PATH D:\__DEV\Ho\undangan\resources\views/admin/input/input.blade.php ENDPATH**/ ?>
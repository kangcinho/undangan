<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    

    <title>Pernikahan <?php echo e($data->nama_suami_initial ." & ".  $data->nama_istri_initial); ?></title>

    <!-- CSS  -->
    <!-- Bootstrap -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
    <!-- Root-Icon -->
    <link rel="stylesheet" href="https://cdn.rootpixel.net/assets/rooticon/v2/rooticon.css">
    <link href="https://cdn.jsdelivr.net/npm/remixicon@2.5.0/fonts/remixicon.css" rel="stylesheet">
    <!-- Glide -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.2.0/css/glide.core.min.css" integrity="sha512-YQlbvfX5C6Ym6fTUSZ9GZpyB3F92hmQAZTO5YjciedwAaGRI9ccNs4iw2QTCJiSPheUQZomZKHQtuwbHkA9lgw==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.2.0/css/glide.theme.min.css" integrity="sha512-wCwx+DYp8LDIaTem/rpXubV/C1WiNRsEVqoztV0NZm8tiTvsUeSlA/Uz02VTGSiqfzAHD4RnqVoevMcRZgYEcQ==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Lightgallery -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/lightgallery-js/1.4.0/css/lightgallery.min.css" integrity="sha512-kwJUhJJaTDzGp6VTPBbMQWBFUof6+pv0SM3s8fo+E6XnPmVmtfwENK0vHYup3tsYnqHgRDoBDTJWoq7rnQw2+g==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <!-- Aos Animation on scroll -->
    <link href="https://unpkg.com/aos@2.3.1/dist/aos.css" rel="stylesheet">
    <!-- App -->
    <link rel="stylesheet" href="<?php echo e(asset('css/tema1/app.min.css')); ?>">
    <style>
        body#index section#opening{
            position:fixed;
            right:0;
            left:0;
            top:0;
            bottom:0;
            z-index:9999;
            padding:10rem 0;
            background-image:linear-gradient(180deg, rgba(0, 0, 0, 0.52) 0%, rgba(0, 0, 0, 0.52) 100%),
            url(" <?php echo e(asset('storage/'. $data->foto_header)); ?>");
            background-size:cover,cover;
            background-repeat:no-repeat;
            background-position:center,center;
            min-height:100vh;
            display:flex;
            flex-direction:column;
            align-items:center;
            justify-content:center
        }
        body#index header#header{
            padding:10rem 0;
            background-image:linear-gradient(180deg, rgba(0, 0, 0, 0.52) 0%, rgba(0, 0, 0, 0.52) 100%),
            url(" <?php echo e(asset('storage/'. $data->foto_header)); ?>");
            background-size:cover,cover;
            background-repeat:no-repeat;
            background-position:center,center;
            min-height:100vh;
            display:flex;
            flex-direction:column;
            align-items:center;
            justify-content:center
        }
        body#index section#section-1 {
            padding: 8rem 0;
            min-height: 54rem;
            background-image: url(" <?php echo e(asset('css/tema1/img/decoration/flowers-top-left.png')); ?> "),
                url("<?php echo e(asset('css/tema1/img/decoration/flowers-bottom-right.png')); ?>"),
                url("<?php echo e(asset('css/tema1/img/decoration/section-1-texture.png')); ?>");
            background-position: left top, right bottom, center center;
            background-size: 13rem, 10rem, cover;
            background-repeat: no-repeat;
            background-color: #f3f3f3;
        }
        body#index section#section-4 {
            padding: 8rem 0;
            min-height: 68rem;
            background-color: #fcf8f2;
            background-image: url("<?php echo e(asset('css/tema1/img/decoration/section-4-texture.png')); ?>"); 
            background-repeat: no-repeat;
            background-size: cover;
        }
        body#index section#section-5 {
            padding: 8rem 0;
            min-height: 28rem;
            background-image: linear-gradient(
                    180deg,
                    rgba(0, 0, 0, 0.52) 0%,
                    rgba(0, 0, 0, 0.52) 100%
                ),
                url(" <?php echo e(asset('storage/'. $data->pepatah_foto)); ?>");
            background-repeat: no-repeat;
            background-size: cover;
            background-position: center;
        }
        body#index section#section-6 .card::before {
            left: -8rem;
            bottom: 0;
            background-image: url("<?php echo e(asset('css/tema1/img/decoration/flower-left.png')); ?>"); 
        }
        body#index section#section-6 .card::after {
            right: -6rem;
            top: 0;
            background-image: url("<?php echo e(asset('css/tema1/img/decoration/flower-right.png')); ?>"); 
        }
        .img-wrapper-spouse::after {
            content: "";
            display: block;
            width: 28.5em;
            height: 28.5em;
            position: absolute;
            left: -2em;
            top: -1.5em;
            background-image: url("<?php echo e(asset('css/tema1/img/decoration/img-wrapper-spouse.png')); ?>");
            background-position: left top;
            background-repeat: no-repeat;
            background-size: 100% 100%;
        }
        .card.card-story.card-story-left::before {
            left: -12em;
            background-image: url("<?php echo e(asset('css/tema1/img/decoration/flower-left.png')); ?>");
        }
        .card.card-story.card-story-left::after {
            align-self: center;
            width: 24em;
            height: 6.4em;
            top: -2.5em;
            left: 7em;
            background-image: url("<?php echo e(asset('css/tema1/img/decoration/card-story-left.png')); ?>");
        }
        .card.card-story.card-story-right::before {
            right: -12em;
            background-image: url("<?php echo e(asset('css/tema1/img/decoration/flower-right.png')); ?>");
        }
        .card.card-story.card-story-right::after {
            align-self: center;
            width: 21em;
            height: 5.4em;
            transform: rotate(3deg);
            top: -2.5em;
            right: 4em;
            background-image: url("<?php echo e(asset('css/tema1/img/decoration/card-story-right.png')); ?>");
        }
    </style>
</head>
<body id="index" class="opening-show" style="cursor: default !important;">
<!-- <body> -->

    <section id="opening">
        <div class="container text-white text-center">
            <h5 class="mb-2">Halo, <span id="guest">Guest</span></h5>
            <h5>Kami mengundang Anda ke Acara Pernikahan kami</h5>
            <h1 class="font-type-secondary my-4"><?php echo e($data->nama_suami ." & ".  $data->nama_istri); ?></h1>
            <h5 class="mb-16"> <?php echo e(date('d-m-Y', strtotime($data->tanggal_nikah))); ?> </h5>
            
            <div class="row justify-content-center">
                <div class="col-auto">
                    <button id="btn-open-opening" class="btn btn-primary page-scroll">Buka Undangan</button>
                </div>
            </div>
        </div>
    </section>

    <nav class="navbar navbar-expand-md">
        <div class="container">
            <div class="navbar-brand px-0 d-md-none">
                <h4 class="font-type-secondary text-white">Our Invitation</h4>
            </div>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <h6 class="mb-0"><i class="ri ri-menu"></i></h6>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav mx-auto align-items-lg-center">
                    
                    <li class="nav-item">
                        <a class="nav-link page-scroll"  href="#section-3">Galeri</a>
                    </li>
                    <li class="nav-item">
                        <h4 class="font-type-secondary d-none d-md-flex">
                            <a class="nav-link page-scroll"  href="#section-1"><?php echo e($data->nama_suami_initial ." & ".  $data->nama_istri_initial); ?></a>
                        </h4>
                        <a class="nav-link page-scroll d-md-none"  href="#section-1">Pengantin</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll"  href="#section-4">Jadwal Pernikahan</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link page-scroll"  href="#section-6">RSVP</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <header id="header">
        <div class="container text-white text-center">
            <h6 class="text-dec text-dec-white">Pernikahan</h6>
            <h1 class="font-type-secondary my-6"><?php echo e($data->nama_suami ." & ".  $data->nama_istri); ?></h1>
            <h5><?php echo e(date('d-m-Y', strtotime($data->tanggal_nikah))); ?></h5>
        </div>
    </header>

    <section id="section-1">
        <div class="container text-center">
            <div class="row justify-content-center mb-5 mb-md-10">
                <div class="col-lg-7">
                    <h2 class="font-type-secondary font-bold">“<?php echo e($data->kata_mutiara); ?>”</h2>
                </div>
            </div>  
            <div class="row g-0 g-md-4 align-items-center justify-content-center py-8 overflow-hidden">
                <div class="col col-md-4 align-self-start d-flex flex-column align-items-center" data-aos="fade-right" data-aos-duration="1000">
                    <div class="img-wrapper-spouse mb-6" data-aos="fade-right" data-aos-offset="-100" data-aos-duration="1000">
                        <div class="img-wrapper">
                        <img src="<?php echo e(asset('storage/'. $data->foto_suami )); ?>" alt="">
                        </div>
                    </div>
                    <h3 class="font-type-secondary font-bold mb-4" data-aos="fade-right"  data-aos-offset="-100" data-aos-duration="1200"><?php echo e($data->nama_suami); ?></h3>
                    <h5 class="mb-3" data-aos="fade-right"  data-aos-offset="-100" data-aos-duration="1300">Putra dari</h5>
                    <h5 data-aos="fade-right"  data-aos-offset="-100" data-aos-duration="1400">Bapak <?php echo e($data->nama_suami_ortu_bapak); ?></h5>
                    <h5 data-aos="fade-right"  data-aos-offset="-100" data-aos-duration="1500">Ibu <?php echo e($data->nama_suami_ortu_ibu); ?></h5>
                </div>
                <div class="col-auto col-lg-3" data-aos="fade-up" data-aos-duration="1200">
                    <h1>&</h1>
                </div>
                <div class="col col-md-4 align-self-start d-flex flex-column align-items-center">
                    <div class="img-wrapper-spouse mb-6" data-aos="fade-left" data-aos-offset="-100" data-aos-duration="1000">
                        <div class="img-wrapper">
                            <img src="<?php echo e(asset('storage/'. $data->foto_istri )); ?>" alt="">
                        </div>
                    </div>
                    <h3 class="font-type-secondary font-bold mb-4" data-aos="fade-left"  data-aos-offset="-100" data-aos-duration="1200"><?php echo e($data->nama_istri); ?></h3>
                    <h5 class="mb-3" data-aos="fade-left"  data-aos-offset="-100" data-aos-duration="1300">Putri dari</h5>
                    <h5 data-aos="fade-left"  data-aos-offset="-100" data-aos-duration="1400">Bapak <?php echo e($data->nama_istri_ortu_bapak); ?></h5>
                    <h5 data-aos="fade-left"  data-aos-offset="-100" data-aos-duration="1500">Ibu <?php echo e($data->nama_istri_ortu_ibu); ?></h5>
                </div>
            </div>
        </div>
    </section>
    <?php if(count($data->story) > 0): ?>
        <section id="section-2">
            <div class="container">
                <h6 class="text-center text-spacing-default">KISAH KITA</h6>
                <h2 class="font-type-secondary text-center mb-10">Cerita Tentang Kita</h2>

                <div class="row gx-5 justify-content-center py-10 overflow-hidden">
                    
                    <div class="col-lg-5 mb-6 mb-sm-10 mb-lg-0">
                        <?php for($i = 0; $i < count($data->story) ; $i++): ?>
                            <?php if($i % 2 == 0): ?>
                                <?php if($i == 0): ?>
                                    <div class="card card-story card-story-left mx-auto mb-6 mb-sm-10 mb-lg-16" data-aos="card-story-left" data-aos-duration="1200">
                                        <div class="card-body">
                                            <img src="<?php echo e(asset('storage/'. $data->story[$i]->kisah_cinta_foto)); ?>" alt="">
                                        </div>
                                    </div>
                                <?php else: ?>
                                    <div class="card card-story card-story-left mx-auto" data-aos="card-story-left" data-aos-duration="1200">
                                        <div class="card-body">
                                            <img src="<?php echo e(asset('storage/'.$data->story[$i]->kisah_cinta_foto)); ?>" alt="">
                                        </div>
                                    </div>
                                <?php endif; ?>                            
                            <?php else: ?>
                                <div class="text-center text-lg-start b-10 mb-16 mb-lg-50" data-aos="fade-up" data-aos-duration="1200">
                                    <div data-aos="fade-up" data-aos-duration="1300">
                                        <h5><?php echo e($data->story[$i]->kisah_cinta_tahun); ?></h5>
                                        <h4 class="font-type-secondary mb-2"><?php echo e($data->story[$i]->kisah_cinta_judul); ?></h4>
                                    </div>
                                    <p class="text-lg font-light" data-aos="fade-up" data-aos-duration="1500">
                                        <?php echo e($data->story[$i]->kisah_cinta_isi); ?>

                                    </p>
                                </div>
                            <?php endif; ?>
                        <?php endfor; ?>                    
                    </div>

                    <div class="d-none d-lg-block col-lg-auto text-center">
                        <img src="<?php echo e(asset('images/tema1/decoration/list-section-2.svg')); ?>" alt="">
                    </div>
                    
                    
                    
                    <div class="col-lg-5">

                        <?php for($i = 0; $i < count($data->story) ; $i++): ?>
                            <?php if($i % 2 == 0): ?>
                                <div class="text-center text-lg-start b-10 mb-16 mb-lg-50" data-aos="fade-up" data-aos-duration="1200">
                                    <div data-aos="fade-up" data-aos-duration="1300">
                                        <h5><?php echo e($data->story[$i]->kisah_cinta_tahun); ?></h5>
                                        <h4 class="font-type-secondary mb-2"><?php echo e($data->story[$i]->kisah_cinta_judul); ?></h4>
                                    </div>
                                    <p class="text-lg font-light" data-aos="fade-up" data-aos-duration="1500">
                                        <?php echo e($data->story[$i]->kisah_cinta_isi); ?>

                                    </p>
                                </div>        
                            <?php else: ?>
                                <div class="card card-story card-story-right mx-auto  mb-6 mb-sm-10 mb-lg-16" data-aos="card-story-right" data-aos-duration="1200">
                                    <div class="card-body">
                                        <img src="<?php echo e(asset('storage/'.$data->story[$i]->kisah_cinta_foto)); ?>" alt="">
                                    </div>
                                </div>
                            <?php endif; ?>
                        <?php endfor; ?>
                    </div>
                </div>            
            </div>
        </section>   
    <?php endif; ?> 
    
    <section id="section-5">
        <div class="container text-white text-center aos-init aos-animate" data-aos="fade-up" data-aos-offset="-150" data-aos-duration="1200">
            <h5 class="font-normal">
                "<?php echo e($data->pepatah_kata); ?>"
            </h5>
            <div class="bg-white mx-auto my-8" style="width: 14rem; height: 3px;"></div>
            <h5 class="font-bold"><?php echo e($data->pepatah_author); ?></h5>
        </div>
    </section>

    <section id="section-3">
        <div class="container">
            <div id="row-lightgallery" class="row align-items-stretch g-4 g-lg-5 py-10 overflow-hidden">
                <div data-src="<?php echo e(asset('storage/'. $data->galeri_top1 )); ?>" class="col-md-6 col-lg-4 order-2 order-lg-1" data-aos="fade-up" data-aos-offset="-200" data-aos-duration="1200">
                    <div class="img-wrapper img-wrapper-gallery-1">
                        <img src="<?php echo e(asset('storage/'. $data->galeri_top1 )); ?>" alt="">
                    </div>
                </div>
                <div class="col-lg-8 d-flex order-1 order-lg-2">
                    <div class="row g-lg-5">
                        <div class="col-12 text-white">
                            <h6 class="text-spacing-default">GALERI</h6>
                            <h4 class="font-type-secondary mb-6">Foto Prewedding Kami</h4>
                            <p class="text-lg font-light mb-4 mb-lg-2">
                                <?php echo e($data->galeri_keterangan); ?>

                            </p>
                        </div>
                        <div class="col-6 align-self-end" data-aos="fade-up" data-aos-offset="-250" data-aos-duration="1400">
                            <div data-src="<?php echo e(asset('storage/'. $data->galeri_top2 )); ?>" class="img-wrapper img-wrapper-gallery-2">
                                <img src="<?php echo e(asset('storage/'. $data->galeri_top2 )); ?>" alt="">
                            </div>
                        </div>
                        <div class="col-6 align-self-end" data-aos="fade-up" data-aos-offset="-250" data-aos-duration="1600">
                            <div data-src="<?php echo e(asset('storage/'. $data->galeri_top3 )); ?>" class="img-wrapper img-wrapper-gallery-2">
                                <img src="<?php echo e(asset('storage/'. $data->galeri_top3 )); ?>" alt="">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6 col-lg-12 order-2" data-aos="fade-up" data-aos-offset="-250" data-aos-duration="1800">
                    <div data-src="<?php echo e(asset('storage/'. $data->galeri_middle )); ?>" class="img-wrapper img-wrapper-gallery-3">
                        <img src="<?php echo e(asset('storage/'. $data->galeri_middle )); ?>" alt="">
                    </div>
                </div>
                <div class="col-12 order-3 ">
                    <div class="row g-lg-5 align-items-stretch g-4 g-lg-5 py-10 overflow-hidden">
                        <div class="col-lg-4 col-sm-6 col-xs-12" data-aos="fade-up" data-aos-offset="-250" data-aos-duration="1400">
                            <div data-src="<?php echo e(asset('storage/'. $data->galeri_bottom1 )); ?>" class="img-wrapper img-wrapper-gallery-2">
                                <img src="<?php echo e(asset('storage/'. $data->galeri_bottom1 )); ?>" alt="">
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 col-xs-12" data-aos="fade-up" data-aos-offset="-250" data-aos-duration="1400">
                            <div data-src="<?php echo e(asset('storage/'. $data->galeri_bottom2 )); ?>" class="img-wrapper img-wrapper-gallery-2">
                                <img src="<?php echo e(asset('storage/'. $data->galeri_bottom2 )); ?>" alt="">
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 col-xs-12" data-aos="fade-up" data-aos-offset="-250" data-aos-duration="1400">
                            <div data-src="<?php echo e(asset('storage/'. $data->galeri_bottom3 )); ?>" class="img-wrapper img-wrapper-gallery-2">
                                <img src="<?php echo e(asset('storage/'. $data->galeri_bottom3 )); ?>" alt="">
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 col-xs-12" data-aos="fade-up" data-aos-offset="-250" data-aos-duration="1400">
                            <div data-src="<?php echo e(asset('storage/'. $data->galeri_bottom4 )); ?>" class="img-wrapper img-wrapper-gallery-2">
                                <img src="<?php echo e(asset('storage/'. $data->galeri_bottom4 )); ?>" alt="">
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 col-xs-12" data-aos="fade-up" data-aos-offset="-250" data-aos-duration="1400">
                            <div data-src="<?php echo e(asset('storage/'. $data->galeri_bottom5 )); ?>" class="img-wrapper img-wrapper-gallery-2">
                                <img src="<?php echo e(asset('storage/'. $data->galeri_bottom5 )); ?>" alt="">
                            </div>
                        </div>
                        <div class="col-lg-4 col-sm-6 col-xs-12" data-aos="fade-up" data-aos-offset="-250" data-aos-duration="1400">
                            <div data-src="<?php echo e(asset('storage/'. $data->galeri_bottom6 )); ?>" class="img-wrapper img-wrapper-gallery-2">
                                <img src="<?php echo e(asset('storage/'. $data->galeri_bottom6 )); ?>" alt="">
                            </div>
                        </div>
                    </div>                    
                </div>
                <?php if(isset($data->video)): ?>
                <div class="col-12 order-4">
                    <div class="ratio ratio-16x9">
                        <video autoplay muted>
                            <source src="<?php echo e(asset('storage/'. $data->video)); ?>" type="video/mp4">
                        </video>
                    </div>
                </div>
                <?php endif; ?>                     
            </div>
        </div>
    </section>

    <section id="section-4">
        <div class="container text-center">
            <div class="row justify-content-center mb-10 overflow-hidden">
                <div class="col-lg-8" data-aos="fade-up" data-aos-offset="-200" data-aos-duration="1200">
                    <h6 class="font-light text-spacing-default">JADWAL PERNIKAHAN</h6>
                    <h4 class="font-type-secondary mt-2 mb-4"> <?php echo e($data->jadwal_nikah_pembuka); ?></h4>
                    <h5 class="font-light">
                        <?php echo e($data->jadwal_nikah_isi); ?>

                    </h5>
                </div>
            </div>

            <div class="row justify-content-center mb-10 overflow-hidden">
                <div class="col-lg-4 col-xl-3" data-aos="zoom-in" data-aos-offset="-200" data-aos-duration="1200">
                    <h2 class="font-type-secondary mb-8">Resepsi</h2>

                    <h6 class="text-spacing-default mb-2">Hari dan Tanggal</h6>
                    <h6 class="text-primary font-bold mb-6"> <?php echo e($data->jadwal_nikah_tanggal); ?> </h6>

                    <h6 class="text-spacing-default mb-2">Waktu</h6>
                    <h6 class="text-primary font-bold mb-6"><?php echo e($data->jadwal_nikah_waktu); ?></h6>

                    <h6 class="text-spacing-default mb-2">Lokasi</h6>
                    <h6 class="text-primary font-bold mb-6"><?php echo e($data->jadwal_nikah_lokasi); ?></h6>

                    <a href="<?php echo e($data->jadwal_nikah_lokasi_link); ?>" class="btn btn-primary">
                        <i class="ri ri-pin mr-1"></i> Lihat Lokasi
                    </a>
                </div>
            </div>

            <div class="row justify-content-center pt-10">
                <div class="col-lg-8 text-center">
                    <h5 class="font-light mb-4">
                        <?php echo e($data->jadwal_isi_bottom); ?>

                    </h5>
                    <h4 class="font-type-secondary mt-2 mb-4"><?php echo e($data->jadwal_penutup); ?></h4>
                </div>
            </div>
        </div>
    </section>

    <section id="section-6">
        <div class="container">
            <div class="text-center mb-10">
                <h6 class="text-spacing-default mb-2">RSPV</h6>
                <h2 class="font-type-secondary">Apakah Anda Akan Hadir?</h2>
            </div>
            <form id="formReservation">
                <div class="row justify-content-center">
                    <div class="col-lg-8" data-aos="zoom-in" data-aos-offset="-100" data-aos-duration="1200">
                        <div class="card">
                            <div class="card-body">    
                                <?php echo csrf_field(); ?>
                                <input type="hidden" value="<?php echo e($data->id); ?>" name="invite_id">                    
                                <div class="mb-5">
                                    <label for="" class="form-label">Nama</label>
                                    <input 
                                        type="text" 
                                        class="form-control" 
                                        placeholder="Nama Lengkap Anda"
                                        name="nama"
                                        id="ucapanNama"
                                        required>
                                </div>
                                <div class="mb-5">
                                    <label for="" class="form-label">Nomor WhatsApp atau HP</label>
                                    <input 
                                        type="text" 
                                        class="form-control" 
                                        placeholder="Nomor WhatsApp atau HP Anda"
                                        name="no_wa"
                                        id="ucapanNoWa"
                                        required>
                                </div>
                                <div class="mb-5">
                                    <div class="form-check mb-2">
                                        <input class="form-check-input" type="radio" name="is_hadir" value="1" checked />
                                        <label class="form-check-label" for="flexRadioDefault1">
                                            Ya, saya akan hadir
                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="is_hadir" value="0">
                                        <label class="form-check-label" for="flexRadioDefault2">
                                            Tidak, saya tidak bisa hadir
                                        </label>
                                    </div>
                                </div>
                                <div class="mb-5">
                                    <label for="" class="form-label">Ucapan dan Doa Anda</label>
                                    <textarea 
                                        type="text" 
                                        class="form-control" 
                                        rows="3"
                                        name="ucapan_dan_doa"
                                        placeholder="Tulis ucapan dan doa anda untuk mempelai pengantin" id="ucapanDoa" 
                                        required></textarea>
                                </div>
                                <button class="btn btn-primary">Kirim Ucapan</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </section>

    <section id="section-7">
        <div class="container">
            <ul class="list-group list-group-flush" id="listUcapan"></ul>
            <!-- closing -->
            <div class="text-center py-10">
                <h4 class="font-type-secondary font-bold mb-6">Terimakasih atas doa restunya</h4>
                <h2 class="font-type-secondary font-bold mb-10"><?php echo e($data->nama_suami_initial ." & ".  $data->nama_istri_initial); ?></h2>
                <img src="<?php echo e(asset('images/tema1/decoration/closing.png')); ?>" alt="" class="w-25rem">
            </div>
        </div>
    </section>

    <footer id="footer">
        <div class="container">
            <div class="row">
                <div class="col-sm mb-3 mb-md-0">Undangan Online by - FS Photostory</div>
                <div class="col-sm-auto">
                    <div class="btn-toolbar" role="toolbar" aria-label="Toolbar with button groups">
                        <div class="btn-group mr-2" role="group" >
                            <button class="btn btn-light">                        
                                <a href="https://www.instagram.com/fs.photostorybali/" style="text-decoration: none;">
                                    <i class="ri-instagram-line"></i>
                                </a>                        
                            </button>
                        </div>    
                        <div class="btn-group mr-2" role="group" >
                            <button class="btn btn-light">                        
                                <a href="https://wa.me/6289664302776/" style="text-decoration: none;">
                                    <i class="ri-whatsapp-line"></i>
                                </a>                        
                            </button>
                        </div>      
                    </div>                              
                </div>
            </div>
        </div>
    </footer>

    <button id="btn-play" class="btn btn-light">
        <i class="ri-volume-up-line"></i>
    </button>
    <a href="#header" id="btn-to-top" class="btn btn-light page-scroll  ">
        <i class="ri-arrow-up-line"></i>
    </a>

    <audio controls id="audio" class="d-none">
        <source src="<?php echo e(asset('storage/'.  $data->music )); ?>" type="audio/mpeg">
        <!-- Your browser does not support the audio element. -->
    </audio>

    <!-- JS -->
    <!-- Bootstrap -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    <!-- Lightgallery -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lightgallery-js/1.4.0/js/lightgallery.min.js" integrity="sha512-b4rL1m5b76KrUhDkj2Vf14Y0l1NtbiNXwV+SzOzLGv6Tz1roJHa70yr8RmTUswrauu2Wgb/xBJPR8v80pQYKtQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Countdown -->
    <script src="https://cdn.jsdelivr.net/npm/timezz@6.1.0/dist/timezz.min.js"></script>
    <!-- Glide -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/Glide.js/3.2.0/glide.min.js" integrity="sha512-IkLiryZhI6G4pnA3bBZzYCT9Ewk87U4DGEOz+TnRD3MrKqaUitt+ssHgn2X/sxoM7FxCP/ROUp6wcxjH/GcI5Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- Aos Animation os scroll -->
    <script src="https://unpkg.com/aos@2.3.1/dist/aos.js"></script>
    <!-- Anime js -->
    <script src="https://cdnjs.cloudflare.com/ajax/libs/animejs/3.2.1/anime.min.js" integrity="sha512-z4OUqw38qNLpn1libAN9BsoDx6nbNFio5lA6CuTp9NlK83b89hgyCVq+N5FdBJptINztxn1Z3SaKSKUS5UP60Q==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>
    <!-- App -->
    <script src="<?php echo e(asset('js/tema1/app.js')); ?>"></script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    <script>
        $("#formReservation").submit(function(event){
            event.preventDefault();

            var $form = $(this);
            var serializedData = $form.serialize();

            $.ajax({
                url: "/reservasi",
                type: "post",
                data: serializedData ,
                success: function (response) {
                    const ucapan = `
                        <li class="li list-group-item">
                            <h5 class="font-bold mb-2">${ response.nama }</h5>
                            <p class="text-lg font-light mb-3">
                                ${ response.ucapan_dan_doa }
                            </p>
                            <div class="text-dark-500 font-light">${ response.dateUcapan }</div>
                        </li>
                    `;
                    $("#listUcapan").append(ucapan);
                    $("#formReservation")[0].reset();
                }
            });
        })

        $(document).ready(function(){
            $.ajax({
                url: "/reservasi/<?php echo e($data->url_invite); ?>",
                type: "get",
                success: function (response) {
                    response.forEach( res => {
                        const ucapan = `
                            <li class="li list-group-item">
                                <h5 class="font-bold mb-2">${ res.nama }</h5>
                                <p class="text-lg font-light mb-3">
                                    ${ res.ucapan_dan_doa }
                                </p>
                                <div class="text-dark-500 font-light">${ res.dateUcapan }</div>
                            </li>
                        `;
                        $("#listUcapan").append(ucapan);
                    })
                }
            });
        })
    </script>
</body>
</html>
<?php /**PATH D:\__DEV\Ho\undangan\resources\views/tema1/thema1.blade.php ENDPATH**/ ?>
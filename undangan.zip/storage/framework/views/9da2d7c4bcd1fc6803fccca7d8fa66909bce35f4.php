
  


<nav class="navbar navbar-dark bg-primary">
  <div class="container">
    <a class="navbar-brand" href="#">Undangan</a>
    
    <ul class="nav  ">
      <li class="nav-item">
        <a class="nav-link text-white" href="<?php echo e(url('admin/list')); ?>">List</a>
      </li>
      <li class="nav-item">
        <a class="nav-link text-white" href="<?php echo e(url('admin/input')); ?>">Input</a>
      </li>
      <?php if(auth()->guard()->check()): ?>
        <li class="nav-item">
          <form action="/admin/logout" method="post">
            <?php echo csrf_field(); ?>
            <button type="submit" class="btn btn-text nav-link text-white">Logout</button>
          </form>
        </li>
      <?php endif; ?>
    </ul>
  </div>
</nav>
<?php /**PATH D:\__DEV\Ho\undangan\resources\views/share/nav.blade.php ENDPATH**/ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">    
    <title>DAFTAR DATA PERNIKAHAN</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">
</head>
<body>
  <?php echo $__env->make('share.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="container">
      <h1>Daftar Client</h1>
      <table class="table">
        <thead>
          <tr>
            <th scope="col">URL Undangan</th>
            <th scope="col">Nama Suami</th>
            <th scope="col">Nama Istri</th>
            <th scope="col">Tanggal Nikah</th>
            <th scope="col">Action</th>
          </tr>
        </thead>
        <tbody>
          <?php if(count($invites) > 0): ?>
            <?php $__currentLoopData = $invites; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $invite): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td scope="row"> <?php echo e($invite->url_invite); ?></td>
                <td scope="row"> <?php echo e($invite->nama_suami); ?></td>
                <td scope="row"> <?php echo e($invite->nama_istri); ?></td>
                <td scope="row"> <?php echo e(date('d-m-Y', strtotime($invite->tanggal_nikah))); ?></td>
                <td>
                  <a class="btn btn-primary" href="<?php echo e(url('/'. $invite->url_invite)); ?>">Lihat Undangan</a>
                  <a class="btn btn-warning" href="<?php echo e(url('admin/update/'. $invite->id)); ?>">Edit</a>
                  <a class="btn btn-danger" href="javascript:void(0)" onClick="confirmDelete('<?php echo e($invite->nama_suami); ?>' , '<?php echo e($invite->nama_istri); ?>' , '<?php echo e(url("admin/delete/". $invite->url_invite)); ?>' )">Hapus</a>
                </td>
              </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php endif; ?>
               
        </tbody>
      </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js" integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous"></script>
    <script>
      function confirmDelete(namaSuami, namaIstri, url) {
        if(confirm(`Yakin Hapus Undangan ${namaSuami} - ${namaIstri}`)){
          window.location.href = url
        }
      }
    </script>
</body>
</html>
<?php /**PATH D:\__DEV\Ho\undangan\resources\views/list/list.blade.php ENDPATH**/ ?>